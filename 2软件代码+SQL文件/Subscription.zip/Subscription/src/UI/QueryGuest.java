package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import UI.Database;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class QueryGuest extends JPanel {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JButton btnNewButton;
	JScrollPane scrollPane;
   	JTable table;
   	private ResultSet rs;
	DefaultTableModel dtm;
	String columns[] =  {"���","����","�绰","��ַ","��������"};
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					QueryGuest frame = new QueryGuest();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public QueryGuest() {
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dtm = new DefaultTableModel();
		dtm.setColumnCount(5);
		dtm.setColumnIdentifiers(columns);
		
		table = new JTable(dtm); 
 
		
		
		setBounds(100, 100, 545, 344);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("���");
		lblNewLabel.setBounds(10, 66, 60, 23);
		add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(43, 65, 75, 26);
		add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u59D3\u540D");
		lblNewLabel_1.setBounds(10, 101, 60, 23);
		add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(43, 100, 75, 26);
		add(textField_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u7535\u8BDD");
		lblNewLabel_2.setBounds(10, 134, 60, 23);
		add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(43, 134, 75, 26);
		add(textField_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u5730\u5740");
		lblNewLabel_3.setBounds(10, 172, 60, 23);
		add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(43, 171, 75, 26);
		add(textField_3);
		
		JLabel lblNewLabel_4 = new JLabel("\u90AE\u7F16");
		lblNewLabel_4.setBounds(10, 207, 60, 23);
		add(lblNewLabel_4);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(43, 206, 75, 26);
		add(textField_4);
		
		btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("��ѯ�˿���Ϣ");  
				 
        		int rc=dtm.getRowCount(); 
        	    for(int i=0;i<rc;i++){
        			dtm.removeRow(0);
        		} 
        	    
        	    Database.joinDB();
        		String mySql = "select GNO,GNA,GTE,G.GAD,AD.GPO from G,AD where AD.GAD = G.GAD";
        		Boolean myflag = new Boolean(true);
        		if(textField.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and GNO = "+"'"+textField.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where GNO = "+"'"+textField.getText()+"'";
        			}
        		}
        		if(textField_1.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and GNA = "+"'"+textField_1.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where GNA = "+"'"+textField_1.getText()+"'";
        			}
        		}
        		if(textField_2.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and GTE = "+"'"+textField_2.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where GTE = "+"'"+textField_2.getText()+"'";
        			}
        		}
        		if(textField_3.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and G.GAD = "+"'"+textField_3.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where G.GAD = "+"'"+textField_3.getText()+"'";
        			}
        		}
        		if(textField_4.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and AD.GPO = "+"'"+textField_4.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where AD.GPO = "+"'"+textField_4.getText()+"'";
        			}
        		} 
        		
        		System.out.println(mySql);
    		    rs=Database.executeQuery(mySql);
    			if(Database.recCount(rs)>0){ 
        			try{ 
        				while(rs.next()){ 
        					String GNO = rs.getString("GNO");  
        					String GNA = rs.getString("GNA");  
        					String GTE =  rs.getString("GTE");  
        					String GAD = rs.getString("GAD");   
        					String GPO = rs.getString("GPO");   
        					Vector v = new Vector(); 
        					v.add(GNO);
        					v.add(GNA);
        					v.add(GTE);
        					v.add(GAD);
        					v.add(GPO);  
        					dtm.addRow(v); 
       					}
        			}
        		   	catch(Exception eRIQ){}
        		}
			}
		});
		btnNewButton.setBounds(25, 252, 75, 23);
		add(btnNewButton);
		
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(126, 10, 391, 295);
		add(scrollPane);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
//		setContentPane(contentPane);
		rs=Database.executeQuery("select GNO,GNA,GTE,G.GAD,AD.GPO from G,AD where AD.GAD = G.GAD");
		if(Database.recCount(rs)>0){ 
			try{ 
				while(rs.next()){ 
					String GNO = rs.getString("GNO");  
					String GNA = rs.getString("GNA");  
					String GTE =  rs.getString("GTE");  
					String GAD = rs.getString("GAD");   
					String GPO = rs.getString("GPO");   
					Vector v = new Vector(); 
					v.add(GNO);
					v.add(GNA);
					v.add(GTE);
					v.add(GAD);
					v.add(GPO);  
					dtm.addRow(v); 
					}
			}
		   	catch(Exception eRIQ){}
		}
	}
}
