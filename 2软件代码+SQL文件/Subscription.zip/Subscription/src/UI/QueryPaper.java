package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import UI.Database;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class QueryPaper extends JPanel {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JButton btnNewButton;
	JScrollPane scrollPane;
   	JTable table;
   	private ResultSet rs;
	DefaultTableModel dtm;
	String columns[] =  {"���","����","����","��ʽ","��λ"};
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					QueryPaper frame = new QueryPaper();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public QueryPaper() {
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dtm = new DefaultTableModel();
		dtm.setColumnCount(5);
		dtm.setColumnIdentifiers(columns);
		
		table = new JTable(dtm); 
 
		
		
		setBounds(100, 100, 545, 344);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("���");
		lblNewLabel.setBounds(10, 66, 60, 23);
		add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(43, 65, 75, 26);
		add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("����");
		lblNewLabel_1.setBounds(10, 101, 60, 23);
		add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(43, 100, 75, 26);
		add(textField_1);
		
		JLabel lblNewLabel_2 = new JLabel("����");
		lblNewLabel_2.setBounds(10, 134, 60, 23);
		add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(43, 134, 75, 26);
		add(textField_2);
		
		JLabel lblNewLabel_3 = new JLabel("����");
		lblNewLabel_3.setBounds(10, 172, 60, 23);
		add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(43, 171, 75, 26);
		add(textField_3);
		
		JLabel lblNewLabel_4 = new JLabel("��λ");
		lblNewLabel_4.setBounds(10, 207, 60, 23);
		add(lblNewLabel_4);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(43, 206, 75, 26);
		add(textField_4);
		
		btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("��ѯ��ֽ��Ϣ");  
				 
        		int rc=dtm.getRowCount(); 
        	    for(int i=0;i<rc;i++){
        			dtm.removeRow(0);
        		} 
        	    
        	    Database.joinDB();
        		String mySql = "select * from P ";
        		Boolean myflag = new Boolean(false);
        		if(textField.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and PNO = "+"'"+textField.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where PNO = "+"'"+textField.getText()+"'";
        			}
        		}
        		if(textField_1.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and PNA = "+"'"+textField_1.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where PNA = "+"'"+textField_1.getText()+"'";
        			}
        		}
        		if(textField_2.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and PPR = "+textField_2.getText();
        			}else {//��һ��
        				myflag = true;
        				mySql += " where PPR = "+textField_2.getText();
        			}
        		}
        		if(textField_3.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and PSI = "+"'"+textField_3.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where PSI = "+"'"+textField_3.getText()+"'";
        			}
        		}
        		if(textField_4.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and PDW = "+"'"+textField_4.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where PDW = "+"'"+textField_4.getText()+"'";
        			}
        		} 
        		
        		
    		    rs=Database.executeQuery(mySql);
    			if(Database.recCount(rs)>0){ 
        			try{ 
        				while(rs.next()){ 
        					String PNO = rs.getString("PNO"); 
        					String PNA = rs.getString("PNA"); 
        					String PPR = (""+ rs.getInt("PPR") ); 
        					String PSI = rs.getString("PSI"); 
        					String PDW = rs.getString("PDW");  
        					Vector v = new Vector(); 
        					v.add(PNO);
        					v.add(PNA);
        					v.add(PPR);
        					v.add(PSI);
        					v.add(PDW);  
        					dtm.addRow(v); 
       					}
        			}
        		   	catch(Exception eRIQ){}
        		}
			}
		});
		btnNewButton.setBounds(25, 252, 75, 23);
		add(btnNewButton);
		
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(126, 10, 391, 295);
		add(scrollPane);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
//		setContentPane(contentPane);
	    rs=Database.executeQuery("select * from P");
		if(Database.recCount(rs)>0){ 
			try{ 
				while(rs.next()){ 
					String PNO = rs.getString("PNO"); 
					String PNA = rs.getString("PNA"); 
					String PPR = (""+ rs.getInt("PPR") ); 
					String PSI = rs.getString("PSI"); 
					String PDW = rs.getString("PDW");  
					Vector v = new Vector(); 
					v.add(PNO);
					v.add(PNA);
					v.add(PPR);
					v.add(PSI);
					v.add(PDW);  
					dtm.addRow(v); 
				}
			}
		   	catch(Exception eRIQ){}
		}
	}
}
