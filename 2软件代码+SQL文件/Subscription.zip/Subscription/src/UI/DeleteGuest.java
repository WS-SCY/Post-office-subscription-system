package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import UI.Database;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;

public class DeleteGuest extends JPanel {

	private JPanel contentPane;
	private JTextField textField;
	private JButton btnNewButton;
	JScrollPane scrollPane;
   	JTable table;
   	private ResultSet rs;
	DefaultTableModel dtm;
	String columns[] =  {"���","����","�绰","��ַ","��������"};
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					DeleteGuest frame = new DeleteGuest();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public DeleteGuest() {
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dtm = new DefaultTableModel();
		dtm.setColumnCount(5);
		dtm.setColumnIdentifiers(columns);
		
		table = new JTable(dtm); 
 
		
		
		setBounds(100, 100, 545, 344);
		setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(25, 77, 75, 26);
		add(textField);
		textField.setColumns(10);
		
		btnNewButton = new JButton("\u5220\u9664");
		btnNewButton.setFont(new Font("����", Font.PLAIN, 15));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				System.out.println("ɾ��");
				String myid = textField.getText(); 
				int opt = JOptionPane.showConfirmDialog(null, "ȷ��ɾ���˿���Ϣ��?","",JOptionPane.OK_CANCEL_OPTION );  //0ȷ��  2ȡ��
				if(opt == 0) {
					if(Database.joinDB()) {
		        		int rc=dtm.getRowCount(); 
		        	    for(int i=0;i<rc;i++){
		        			dtm.removeRow(0);
		        		} 
						Database.executeSQL("delete from PG where GNO = '"+myid+"'");
						Database.executeSQL( "delete from G where GNO = '" +myid+"'");
						rs=Database.executeQuery("select GNO,GNA,GTE,G.GAD,AD.GPO from G,AD where AD.GAD = G.GAD ");
						if(Database.recCount(rs)>0){ 
							try{ 
								while(rs.next()){ 
									String GNO = rs.getString("GNO");  
									String GNA = rs.getString("GNA");  
									String GTE =  rs.getString("GTE");  
									String GAD = rs.getString("GAD");   
									String GPO = rs.getString("GPO");   
									Vector v = new Vector(); 
									v.add(GNO);
									v.add(GNA);
									v.add(GTE);
									v.add(GAD);
									v.add(GPO);  
									dtm.addRow(v); 
									}
							}
						   	catch(Exception eRIQ){}
						}
					}
				}
				else {
					;
				}

			}
		});
		  
		btnNewButton.setBounds(25, 207, 75, 23);
		add(btnNewButton);
		
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(126, 10, 391, 295);
		add(scrollPane);
		
		JLabel lblNewLabel = new JLabel("\u8BF7\u8F93\u5165\u7F16\u53F7\uFF1A");
		lblNewLabel.setBounds(25, 42, 91, 26);
		add(lblNewLabel);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
//		setContentPane(contentPane);
		rs=Database.executeQuery("select GNO,GNA,GTE,G.GAD,AD.GPO from G,AD where AD.GAD = G.GAD");
		if(Database.recCount(rs)>0){ 
			try{ 
				while(rs.next()){ 
					String GNO = rs.getString("GNO");  
					String GNA = rs.getString("GNA");  
					String GTE =  rs.getString("GTE");  
					String GAD = rs.getString("GAD");   
					String GPO = rs.getString("GPO");   
					Vector v = new Vector(); 
					v.add(GNO);
					v.add(GNA);
					v.add(GTE);
					v.add(GAD);
					v.add(GPO);  
					dtm.addRow(v); 
					}
			}
		   	catch(Exception eRIQ){}
		}
	}
}
