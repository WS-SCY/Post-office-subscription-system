package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;
import javax.swing.JSplitPane;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.Toolkit;

public class Functions extends JFrame {
	private JPanel contentPane; 
	JPanel panel = new JPanel(){
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            ImageIcon ii = new ImageIcon("Pic/��ɫ�����.jpg");
            g.drawImage(ii.getImage(), 0, 0, getWidth(), getHeight(), ii.getImageObserver());
        }
    };
	JPanel panel_1 = new JPanel();
	InterfacePaper PIF = new InterfacePaper();
	InterfaceGuest GIF = new InterfaceGuest();
	InterfaceGP SIF = new InterfaceGP();
	InterfaceAccount AIF = new InterfaceAccount();
	
//	private PaperInterface Interface1 = new PaperInterface(); 
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Functions frame = new Functions();
//					InterfacePaper tem = new InterfacePaper(); 
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
	/**
	 * Create the frame.
	 */
	public Functions() {
		setUndecorated(true);
		setShape(new RoundRectangle2D.Double(0, 0, 784, 496, 20, 20));
		setIconImage(Toolkit.getDefaultToolkit().getImage(Functions.class.getResource("/Pic/D.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 784, 496);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		panel.setBackground(Color.BLACK);
		panel.setBounds(0, 0, 115, 496);
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		panel_1.setBackground(new Color(72,173,251));
		panel_1.setBounds(114, 0, 680, 498);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setExtendedState(JFrame.ICONIFIED);
			}
		});
		btnNewButton_2.setIcon(new ImageIcon(Functions.class.getResource("/Pic/green.png")));
		btnNewButton_2.setBackground(Color.CYAN);
		btnNewButton_2.setBounds(598, 10, 15, 15);
		panel_1.add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("");
		btnNewButton_2_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_2_1.setIcon(new ImageIcon(Functions.class.getResource("/Pic/red.png")));
		btnNewButton_2_1.setBackground(Color.RED);
		btnNewButton_2_1.setBounds(639, 10, 15, 15);
		panel_1.add(btnNewButton_2_1);
		PIF.setBounds(0, 0, 669, 496);
		GIF.setBounds(0, 0, 669, 496);
		SIF.setBounds(0, 0,669, 496);
		AIF.setBounds(0, 0, 669, 496);


		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Functions.class.getResource("/Pic/logo.png")));
		lblNewLabel.setForeground(Color.YELLOW);
		lblNewLabel.setBackground(new Color(255, 255, 0));
		lblNewLabel.setBounds(5, 12, 78, 77);
		panel.add(lblNewLabel);
		
		JRadioButton btnNewButton = new JRadioButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.BOLD, 13));
		
		
		btnNewButton.setForeground(Color.WHITE); 
		btnNewButton.setIcon(new ImageIcon(Functions.class.getResource("/Pic/\u62A5\u7EB8-.png")));
		btnNewButton.addMouseListener(new MouseAdapter() {  
			public void mousePressed(MouseEvent arg0) {
				System.out.println("��ֽ����"); 
				panel_1.removeAll();
				panel_1.add(PIF);
				panel_1.repaint();
				PIF.repaint();
			}
		}); 
		btnNewButton.setBounds(33, 104, 61, 67); 		 
		panel.add(btnNewButton);
		
		JRadioButton btnNewButton_1 = new JRadioButton("");
		btnNewButton_1.setFont(new Font("΢���ź�", Font.BOLD, 13));
		btnNewButton_1.setIcon(new ImageIcon(Functions.class.getResource("/Pic/\u987E\u5BA2-.png")));
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(new Color(102, 204, 255));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.out.println("�ͻ�����");
				panel_1.removeAll();
				panel_1.add(GIF);
				panel_1.repaint();
				GIF.repaint();
			}
		});
		btnNewButton_1.setBounds(31, 196, 61, 67);
		panel.add(btnNewButton_1);
		
		JRadioButton btnNewButton_1_1 = new JRadioButton("");
		btnNewButton_1_1.setFont(new Font("΢���ź�", Font.BOLD, 13));
		btnNewButton_1_1.setIcon(new ImageIcon(Functions.class.getResource("/Pic/\u8054\u7CFB-.png")));
		btnNewButton_1_1.setForeground(Color.WHITE);
		btnNewButton_1_1.setBackground(new Color(102, 204, 255));
		btnNewButton_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				System.out.println("��������");
				panel_1.removeAll();
				panel_1.add(SIF);
				panel_1.repaint();
				SIF.repaint();
			}
		}); 
		btnNewButton_1_1.setBounds(33, 290, 61, 67);
		panel.add(btnNewButton_1_1);
		
		JRadioButton btnNewButton_1_2 = new JRadioButton("");
		btnNewButton_1_2.setFont(new Font("΢���ź�", Font.BOLD, 13));
		btnNewButton_1_2.setIcon(new ImageIcon(Functions.class.getResource("/Pic/\u8D26\u6237-.png")));
		btnNewButton_1_2.setForeground(Color.WHITE);
		btnNewButton_1_2.setBackground(new Color(102, 204, 255));
		btnNewButton_1_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) { 
				if(Login.authority==2) {
					System.out.println("�˻�����");
					panel_1.removeAll();
					panel_1.add(AIF);
					panel_1.repaint();
					AIF.repaint();
				}
				else {
					int opt = JOptionPane.showConfirmDialog(null, "��û��Ȩ�ޣ�","����",JOptionPane.DEFAULT_OPTION  );  //0ȷ��  2ȡ��
				}
			}
		}); 
		btnNewButton_1_2.setBounds(27, 384, 78, 67);
		panel.add(btnNewButton_1_2);
		
		ButtonGroup  BG = new ButtonGroup();
		BG.add(btnNewButton);
		BG.add(btnNewButton_1);
		BG.add(btnNewButton_1_1);
		BG.add(btnNewButton_1_2);
		
		btnNewButton.setContentAreaFilled(false);    
		btnNewButton.setRolloverIcon(new ImageIcon(Functions.class.getResource("/Pic/��ֽ.png")));  //��� 
		btnNewButton.setSelectedIcon(new ImageIcon(Functions.class.getResource("/Pic/��ֽ.png")));  //ѡ�� 
		
		btnNewButton_1.setContentAreaFilled(false);
		btnNewButton_1.setRolloverIcon(new ImageIcon(Functions.class.getResource("/Pic/�˿�.png")));  //��� 
		btnNewButton_1.setSelectedIcon(new ImageIcon(Functions.class.getResource("/Pic/�˿�.png")));  //ѡ�� 
		
		btnNewButton_1_1.setContentAreaFilled(false);
		btnNewButton_1_1.setRolloverIcon(new ImageIcon(Functions.class.getResource("/Pic/��ϵ.png")));  //��� 
		btnNewButton_1_1.setSelectedIcon(new ImageIcon(Functions.class.getResource("/Pic/��ϵ.png")));  //ѡ�� 
		
		btnNewButton_1_2.setContentAreaFilled(false);
		btnNewButton_1_2.setRolloverIcon(new ImageIcon(Functions.class.getResource("/Pic/�˻�.png")));  //��� 
		btnNewButton_1_2.setSelectedIcon(new ImageIcon(Functions.class.getResource("/Pic/�˻�.png")));
	}
}
