package UI;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Toolkit;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	String LoginID = "SCY";
	String LoginPassword = "666";
	static int authority; 
	static Functions functionframe;
	/**
	 * Launch the application.
	 */ 
	
	public static void main(String[] args) { 
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setUndecorated(true);
		setShape(new RoundRectangle2D.Double(0, 0, 450, 300, 20, 20));
		setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/Pic/D.png"))); 
		setBackground(new Color(51, 255, 102));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(153, 255, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u8BA2\u62A5\u7BA1\u7406\u7CFB\u7EDF");
		lblNewLabel.setFont(new Font("微软雅黑", Font.BOLD, 20));
		lblNewLabel.setBounds(151, 37, 183, 51);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField("SCY");
		textField.setBounds(190, 113, 144, 32);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField("666");
		passwordField.setBounds(190, 174, 144, 32);
		contentPane.add(passwordField);
		
		JLabel label = new JLabel("\u5BC6\u7801\uFF1A");
		label.setFont(new Font("微软雅黑", Font.BOLD, 16));
		label.setBounds(96, 172, 84, 32);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u8D26\u53F7\uFF1A");
		label_1.setFont(new Font("微软雅黑", Font.BOLD, 16));
		label_1.setBounds(96, 113, 84, 32);
		contentPane.add(label_1);
		
		JButton btnNewButton = new JButton("\u786E\u8BA4\u767B\u5F55");  
		btnNewButton.addMouseListener(new MouseAdapter() { 
			public void mouseClicked(MouseEvent arg0) { 
//				new JOptionPane().showMessageDialog(null,"开始连接数据库！","",JOptionPane.ERROR_MESSAGE);
				String sqlString="select * from DBUSER where MYID = '" + textField.getText() + "' and MYPASSWORD = '" +  String.valueOf( passwordField.getPassword() )+ "'";
				System.out.println(sqlString);   
				if (Database.joinDB()) { // cn = getconnection() 
//					new JOptionPane().showMessageDialog(null,"成功连接！","",JOptionPane.ERROR_MESSAGE);
					System.out.println("成功连接数据库!!!"); 
			        Database.rs= Database.executeQuery(sqlString);        	
		        	if(Database.recCount(Database.rs)>0){ 
		        		try {
		        			Database.rs.next();
							authority = Database.rs.getInt("AUTHORITY");
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} 
					    setVisible(false);
					    functionframe = new Functions(); 
					    functionframe.setVisible(true);
					    dispose();
					} 
				    else{ 
				   	   new JOptionPane().showMessageDialog(null,"账号密码不匹配！","",JOptionPane.ERROR_MESSAGE);
				   	} 
//		        	new JOptionPane().showMessageDialog(null,"结束！","",JOptionPane.ERROR_MESSAGE);
				} 
				else System.out.println("数据库连接失败");
			}
		});  
		btnNewButton.setBounds(107, 231, 88, 30);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u6E05\u7A7A");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("清空");
				textField.setText("");
				passwordField.setText("");
			}
		}); 
		btnNewButton_1.setBounds(229, 231, 88, 30);
		contentPane.add(btnNewButton_1);
		
		JPanel panel = new JPanel() {
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon ii = new ImageIcon( "Pic/蓝色背景-135.gif" );
                g.drawImage(ii.getImage(), 0, 0, getWidth(), getHeight(), ii.getImageObserver());
            }
        };
		panel.setBounds(0, 0, 450, 300);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addMouseListener(new MouseAdapter() { 
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_2.setBackground(Color.RED);
		btnNewButton_2.setBounds(414, 12, 15, 15);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("");
		btnNewButton_2_1.addMouseListener(new MouseAdapter() { 
			public void mouseClicked(MouseEvent arg0) {
				setExtendedState(JFrame.ICONIFIED);
			}
		});
		btnNewButton_2_1.setBackground(Color.GREEN);
		btnNewButton_2_1.setBounds(378, 12, 15, 15);
		panel.add(btnNewButton_2_1);
	}
}
