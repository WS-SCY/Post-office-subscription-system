package UI;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class InterfacePaper extends JPanel {
	JPanel panel ;
	QueryPaper QP;
	DeletePaper DP;
	ChangePaper CP;
	AddPaper AP;
	/**
	 * Create the panel.
	 */
	public InterfacePaper() {
		setBackground(new Color(238,238,238));
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u62A5\u7EB8\u7BA1\u7406");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("΢���ź�", Font.BOLD, 22));
		lblNewLabel.setBounds(278, 20, 118, 36);
		add(lblNewLabel);
		
		JButton btnNewButton = new JButton("\u6DFB\u52A0\u62A5\u7EB8");
		btnNewButton.setIcon(new ImageIcon(InterfacePaper.class.getResource("/Pic/\u589E.png")));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("΢���ź�", Font.BOLD, 14));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) { 
				if(Login.authority==2) {
					System.out.println("������ֽ");
					panel.setLayout(null);
					panel.removeAll();
					AP = new AddPaper();
					AP.setLocation(20, 20);
					panel.add(AP);
					AP.repaint();	
				}
				else {
					int opt = JOptionPane.showConfirmDialog(null, "��û��Ȩ�ޣ�"," ",JOptionPane.DEFAULT_OPTION  );  //0ȷ��  2ȡ��
				}
			}
		});
		btnNewButton.setBounds(53, 66, 130, 29);
		add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("\u5220\u9664\u62A5\u7EB8");
		btnNewButton_2.setIcon(new ImageIcon(InterfacePaper.class.getResource("/Pic/\u5220.png")));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setFont(new Font("΢���ź�", Font.BOLD, 14));
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if(Login.authority==2) {
					System.out.println("ɾ����ֽ");
					panel.setLayout(null);
					panel.removeAll();
					DP = new DeletePaper();
					DP.setLocation(20, 20);
					panel.add(DP);
					DP.repaint();
				}
				else {
					int opt = JOptionPane.showConfirmDialog(null, "��û��Ȩ�ޣ�"," ",JOptionPane.DEFAULT_OPTION  );  //0ȷ��  2ȡ��
				}
				
			}
		});
		btnNewButton_2.setBounds(333, 66, 130, 29);
		add(btnNewButton_2);
		
		JButton btnNewButton_1 = new JButton("\u4FEE\u6539\u62A5\u7EB8");
		btnNewButton_1.setIcon(new ImageIcon(InterfacePaper.class.getResource("/Pic/\u6539.png")));
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("΢���ź�", Font.BOLD, 14));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				if(Login.authority==2) {
					System.out.println("�޸ı�ֽ��Ϣ");
					panel.setLayout(null);
					panel.removeAll();
					CP = new ChangePaper();
					CP.setLocation(20, 20);
					panel.add(CP);
					CP.repaint();
				}
				else {
					int opt = JOptionPane.showConfirmDialog(null, "��û��Ȩ�ޣ�","",JOptionPane.DEFAULT_OPTION  );  //0ȷ��  2ȡ��
				}
				
			}
		});
		btnNewButton_1.setBounds(193, 66, 130, 29);
		add(btnNewButton_1);
		
		JButton btnNewButton_2_1 = new JButton("\u67E5\u8BE2\u62A5\u7EB8");
		btnNewButton_2_1.setForeground(new Color(255, 255, 255));
		btnNewButton_2_1.setFont(new Font("΢���ź�", Font.BOLD, 14));
		btnNewButton_2_1.setIcon(new ImageIcon(InterfacePaper.class.getResource("/Pic/\u67E5.png")));
		btnNewButton_2_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				//��ֽ��ѯ
				System.out.println("��ѯ��ֽ");
				panel.setLayout(null);
				panel.removeAll();
				QP = new QueryPaper();
				QP.setLocation(20, 20);
				panel.add(QP);
				QP.repaint();
			}
		});
		btnNewButton_2_1.setBounds(473, 66, 130, 29);
		add(btnNewButton_2_1);
		
		panel = new JPanel();
		panel.setBackground(new Color(238,238,238));
		panel.setBounds(46, 105, 595, 354);
		add(panel);
		
		JPanel panel_1 = new JPanel(){
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon ii = new ImageIcon("Pic/���.jpg");
                g.drawImage(ii.getImage(), 0, 0, getWidth(), getHeight(), ii.getImageObserver());
            }
        };
		panel_1.setBackground(Color.BLACK);
		panel_1.setBounds(0, 0, 692, 96);
		add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton_2_2 = new JButton("");
		btnNewButton_2_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login.functionframe.setExtendedState(JFrame.ICONIFIED);
			}
		});
		btnNewButton_2_2.setIcon(new ImageIcon(InterfacePaper.class.getResource("/Pic/green.png")));
		btnNewButton_2_2.setBackground(Color.CYAN);
		btnNewButton_2_2.setBounds(598, 10, 15, 15);
		panel_1.add(btnNewButton_2_2);
		
		JButton btnNewButton_2_2_1 = new JButton("");
		btnNewButton_2_2_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_2_2_1.setIcon(new ImageIcon(InterfacePaper.class.getResource("/Pic/red.png")));
		btnNewButton_2_2_1.setBackground(Color.CYAN);
		btnNewButton_2_2_1.setBounds(639, 10, 15, 15);
		panel_1.add(btnNewButton_2_2_1);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		 
		
		btnNewButton.setBorderPainted(false); 
		btnNewButton.setContentAreaFilled(false);
		
		btnNewButton_1.setBorderPainted(false); 
		btnNewButton_1.setContentAreaFilled(false);
		
		btnNewButton_2.setBorderPainted(false); 
		btnNewButton_2.setContentAreaFilled(false);
		
		btnNewButton_2_1.setBorderPainted(false); 
		btnNewButton_2_1.setContentAreaFilled(false); 
	}
	
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					JFrame frame = new JFrame();
//					frame.setBounds(10, 91, 634, 356);
//					frame.getContentPane().add( new InterfacePaper() );
//					frame.setVisible(true);
//					
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

}
