package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import UI.Database;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class ChangePaper extends JPanel {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JButton btnNewButton;
	JScrollPane scrollPane;
   	JTable table;
   	private ResultSet rs;
	DefaultTableModel dtm;
	String columns[] =  {"���","����","����","��ʽ","��λ"};
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					ChangePaper frame = new ChangePaper();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public ChangePaper() {
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dtm = new DefaultTableModel();
		dtm.setColumnCount(5);
		dtm.setColumnIdentifiers(columns);
		
		table = new JTable(dtm); 
 
		
		
		setBounds(100, 100, 545, 344);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u8981\u66F4\u65B0\u7684\u7F16\u53F7\uFF1A");
		lblNewLabel.setBounds(10, 31, 108, 23);
		add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(20, 64, 75, 26);
		add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("����");
		lblNewLabel_1.setBounds(10, 141, 60, 23);
		add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(43, 140, 75, 26);
		add(textField_1);
		
		JLabel lblNewLabel_2 = new JLabel("����");
		lblNewLabel_2.setBounds(10, 174, 60, 23);
		add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(43, 174, 75, 26);
		add(textField_2);
		
		JLabel lblNewLabel_3 = new JLabel("����");
		lblNewLabel_3.setBounds(10, 212, 60, 23);
		add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(43, 211, 75, 26);
		add(textField_3);
		
		JLabel lblNewLabel_4 = new JLabel("��λ");
		lblNewLabel_4.setBounds(10, 247, 60, 23);
		add(lblNewLabel_4);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(43, 246, 75, 26);
		add(textField_4);
		
		btnNewButton = new JButton("\u66F4\u6539");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("�޸ı�ֽ��Ϣ");   
        	    Database.joinDB();
        		String mySql = ""; 
        		if(textField.getText().equals("") ||textField_1.getText().equals("")||textField_2.getText().equals("")||textField_3.getText().equals("")||textField_4.getText().equals("")) {
        			int opt = JOptionPane.showConfirmDialog(null, "��������������Ϣ��","",JOptionPane.DEFAULT_OPTION);  //0ȷ��  2ȡ��
        		}else {
        			int opt = JOptionPane.showConfirmDialog(null, "ȷ��������Ϣ��?","",JOptionPane.OK_CANCEL_OPTION );  //0ȷ��  2ȡ��
        			if(opt == 0) {
        				mySql = "update P set PNA = '"+ textField_1.getText()+"' ,PPR = "+textField_2.getText()+" ,PSI ='"+textField_3.getText()+"' ,PDW = '"+textField_4.getText()+"' where PNO = '"+ textField.getText() +"'";
            			Database.executeSQL(mySql);
                   		System.out.println(mySql);  
                   		rs=Database.executeQuery("select * from P");
                		int row=dtm.getRowCount(); 
                	    for(int i=0;i<row;i++){
                			dtm.removeRow(0);
                		} 
                	    
                		if(Database.recCount(rs)>0){ 
                			try{ 
                				while(rs.next()){ 
                					String PNO = rs.getString("PNO"); 
                					String PNA = rs.getString("PNA"); 
                					String PPR = (""+ rs.getInt("PPR") ); 
                					String PSI = rs.getString("PSI"); 
                					String PDW = rs.getString("PDW");  
                					Vector v = new Vector(); 
                					v.add(PNO);
                					v.add(PNA);
                					v.add(PPR);
                					v.add(PSI);
                					v.add(PDW);  
                					dtm.addRow(v); 
                				}
                			}
                		   	catch(Exception eRIQ){}
                		}
        			} 
        		} 
        		
			}
		});
		btnNewButton.setBounds(20, 282, 75, 23);
		add(btnNewButton);
		
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(126, 10, 391, 295);
		add(scrollPane);
		
		JLabel lblNewLabel_5 = new JLabel("\u8981\u66F4\u65B0\u7684\u503C\uFF1A");
		lblNewLabel_5.setBounds(10, 100, 108, 23);
		add(lblNewLabel_5);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
//		setContentPane(contentPane);
	    rs=Database.executeQuery("select * from P");
		if(Database.recCount(rs)>0){ 
			try{ 
				while(rs.next()){ 
					String PNO = rs.getString("PNO"); 
					String PNA = rs.getString("PNA"); 
					String PPR = (""+ rs.getInt("PPR") ); 
					String PSI = rs.getString("PSI"); 
					String PDW = rs.getString("PDW");  
					Vector v = new Vector(); 
					v.add(PNO);
					v.add(PNA);
					v.add(PPR);
					v.add(PSI);
					v.add(PDW);  
					dtm.addRow(v); 
				}
			}
		   	catch(Exception eRIQ){}
		}
	}
}
