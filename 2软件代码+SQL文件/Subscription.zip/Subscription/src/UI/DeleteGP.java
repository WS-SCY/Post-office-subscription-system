
package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import UI.Database;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;

public class DeleteGP extends JPanel {

	private JPanel contentPane;
	private JTextField textField;
	private JButton btnNewButton;
	JScrollPane scrollPane;
   	JTable table;
   	private ResultSet rs;
	DefaultTableModel dtm;
	String columns[] =  {"�˿���","�˿ͱ��","��ֽ��","��ֽ���","�������","Ӧ������"};
	private JTextField textField_1;
	private JLabel lblNewLabel_1;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					DeleteGP frame = new DeleteGP();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public DeleteGP() {
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dtm = new DefaultTableModel();
		dtm.setColumnCount(7);
		dtm.setColumnIdentifiers(columns);
		
		table = new JTable(dtm); 
 
		
		
		setBounds(100, 100, 545, 344);
		setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(25, 77, 75, 26);
		add(textField);
		textField.setColumns(10);
		
		btnNewButton = new JButton("\u5220\u9664");
		btnNewButton.setFont(new Font("����", Font.PLAIN, 15));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				System.out.println("ɾ��"); 
				int opt = JOptionPane.showConfirmDialog(null, "ȷ��ɾ����ֽ��Ϣ��?","",JOptionPane.OK_CANCEL_OPTION );  //0ȷ��  2ȡ��
				if(opt == 0) {
					if(Database.joinDB()) {
		        		int rc=dtm.getRowCount(); 
		        	    for(int i=0;i<rc;i++){
		        			dtm.removeRow(0);
		        		} 
						Database.executeSQL("delete from PG where GNO = '"+textField.getText()+"' and PNO = '"+textField_1.getText()+"'"); 
						rs=Database.executeQuery("select GNA,G.GNO,P.PNA,P.PNO,PPR,N from G,P,PG where G.GNO = PG.GNO and P.PNO = PG.PNO");
						if(Database.recCount(rs)>0){ 
							try{ 
								while(rs.next()){ 
									String GNA = rs.getString("GNA");  
									String GNO = rs.getString("GNO");
									String PNA = rs.getString("PNA");  
									String PNO = rs.getString("PNO");
									int N =  rs.getInt("N");  
									int PPR = rs.getInt("PPR");     
									Vector v = new Vector(); 
									v.add(GNA); 
									v.add(GNO);
									v.add(PNA);
									v.add(PNO);
									v.add(N);
									v.add(N*PPR);  
									dtm.addRow(v); 
								}
							}
						   	catch(Exception eRIQ){}
						}
					}
				}
				else {
					;
				}

			}
		});
		  
		btnNewButton.setBounds(25, 207, 75, 23);
		add(btnNewButton);
		
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(126, 10, 391, 295);
		add(scrollPane);
		
		JLabel lblNewLabel = new JLabel("\u5BA2\u4EBA\u7F16\u53F7\uFF1A");
		lblNewLabel.setBounds(25, 42, 91, 26);
		add(lblNewLabel);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(25, 162, 75, 26);
		add(textField_1);
		
		lblNewLabel_1 = new JLabel("\u62A5\u7EB8\u7F16\u53F7\uFF1A");
		lblNewLabel_1.setBounds(25, 127, 91, 26);
		add(lblNewLabel_1);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0)); 
		rs=Database.executeQuery("select GNA,G.GNO,P.PNA,P.PNO,PPR,N from G,P,PG where G.GNO = PG.GNO and P.PNO = PG.PNO");
		if(Database.recCount(rs)>0){ 
			try{ 
				while(rs.next()){ 
					String GNA = rs.getString("GNA");  
					String GNO = rs.getString("GNO");
					String PNA = rs.getString("PNA");  
					String PNO = rs.getString("PNO");
					int N =  rs.getInt("N");  
					int PPR = rs.getInt("PPR");     
					Vector v = new Vector(); 
					v.add(GNA); 
					v.add(GNO);
					v.add(PNA);
					v.add(PNO);
					v.add(N);
					v.add(N*PPR);  
					dtm.addRow(v); 
				}
			}
		   	catch(Exception eRIQ){}
		}
	}
}
