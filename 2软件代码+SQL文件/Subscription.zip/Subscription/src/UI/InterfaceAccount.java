package UI;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JTextField;

import UI.Database;

import javax.swing.JComboBox;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.beans.VetoableChangeListener;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import javax.swing.JRadioButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.LineBorder;

public class InterfaceAccount extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JComboBox comboBox = new JComboBox();
	JRadioButton rdbtnNewRadioButton;
	private JTextField textField_2;
	static Login newlogin;
	/**
	 * Create the panel.
	 */
	public InterfaceAccount() {
		setBorder(null);
		setBackground(new Color(238,238,238));
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u8D26\u6237\u7BA1\u7406");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("΢���ź�", Font.BOLD, 22));
		lblNewLabel.setBounds(278, 20, 118, 36);
		add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(269, 136, 182, 36);
		add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u65B0\u8D26\u53F7\uFF1A");
		lblNewLabel_1.setBounds(177, 139, 67, 33);
		add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(269, 182, 182, 36);
		add(textField_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\u65B0\u5BC6\u7801\uFF1A");
		lblNewLabel_1_1.setBounds(177, 185, 67, 33);
		add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u6DFB\u52A0\u8D26\u6237");
		lblNewLabel_2.setBounds(282, 111, 54, 15);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("\u5DF2\u6709\u8D26\u53F7\uFF1A");
		lblNewLabel_1_1_1.setBounds(177, 347, 67, 33);
		add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("\u5220\u9664\u8D26\u6237");
		lblNewLabel_2_1.setBounds(282, 319, 54, 15);
		add(lblNewLabel_2_1); 
		
		
		comboBox.setBounds(269, 347, 182, 36);
		add(comboBox);
		
		JButton btnNewButton = new JButton("\u786E\u8BA4\u5220\u9664");
		btnNewButton.addMouseListener(new MouseAdapter() {
			 
			public void mousePressed(MouseEvent arg0) {
				//ɾ���˺�
				String deletename = new String();
				deletename = (String) comboBox.getSelectedItem();
				System.out.println("ɾ��"+deletename);
				int opt = JOptionPane.showConfirmDialog(null, "ȷ��ɾ����?"," ",JOptionPane.OK_CANCEL_OPTION );  //0ȷ��  2ȡ��
				if(opt==0) {//ȷ��
					Database.joinDB();  //�������ݿ�
					String mySql = "delete from DBUSER where MYID = '"+ deletename+"'";  //���ò�ѯ���
					Database.executeSQL(mySql);   //ִ�в�ѯ
					String sql="select * from DBUSER";
					if(Database.joinDB()) {
				        try{
				            Database.rs= Database.executeQuery(sql);    
				            comboBox.removeAllItems();
				        	if(Database.recCount(Database.rs)>0){ 
				         		while(Database.rs.next()){
				         			String name=Database.rs.getString("MYID");
				         			comboBox.addItem(name);
				         		}
				         	}
				        }
				        catch(Exception e){}			
					}
				}else {
					
				}
			}
		});
		btnNewButton.setBounds(473, 347, 91, 36);
		add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("\u786E\u8BA4\u6DFB\u52A0");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				System.out.println("�����û�");
				String MYID = new String();
				String MYPASSWORD = new String();
				MYID = textField.getText();
				MYPASSWORD = textField_1.getText();
				int MYAUTHORITY ;
				if(rdbtnNewRadioButton.isSelected()) MYAUTHORITY = 1;
				else MYAUTHORITY = 2; 
				String mysql = new String();
				mysql = String.format( "INSERT INTO DBUSER VALUES('%s','%s',%d);", MYID,MYPASSWORD,MYAUTHORITY); 
				System.out.println(mysql); 
				int opt = JOptionPane.showConfirmDialog(null, "ȷ��������Ϣ��?"," ",JOptionPane.OK_CANCEL_OPTION );  //0ȷ��  2ȡ��
				if(opt == 0) {  
					Database.executeSQL(mysql);
					String sql="select * from DBUSER";
					if(Database.joinDB()) {
				        try{
				            Database.rs= Database.executeQuery(sql);     
				            comboBox.removeAllItems();
				        	if(Database.recCount(Database.rs)>0){ 
				         		while(Database.rs.next()){
				         			String name=Database.rs.getString("MYID");
				         			comboBox.addItem(name);
				         		}
				         	}
				        }
				        catch(Exception e){}			
					}
				}
				else ;   
			}
		}); 
		btnNewButton_2.setBounds(260, 260, 91, 33);
		add(btnNewButton_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u9009\u62E9\u6743\u9650\uFF1A");
		lblNewLabel_3.setBounds(177, 228, 67, 33);
		add(lblNewLabel_3);
		
		rdbtnNewRadioButton = new JRadioButton("\u67E5\u8BE2");
		rdbtnNewRadioButton.setSelected(true);
		rdbtnNewRadioButton.setBounds(266, 233, 78, 23); 
		add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("\u67E5\u8BE2\u4FEE\u6539");
		rdbtnNewRadioButton_1.setBounds(372, 233, 79, 23);
		add(rdbtnNewRadioButton_1);
		
		
		
		ButtonGroup myButtonGroup = new ButtonGroup();
		myButtonGroup.add(rdbtnNewRadioButton);
		myButtonGroup.add(rdbtnNewRadioButton_1);
		
		JPanel panel = new JPanel() {
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon ii = new ImageIcon("Pic/���.jpg");
                g.drawImage(ii.getImage(), 0, 0, getWidth(), getHeight(), ii.getImageObserver());
            }
        };

		panel.setBounds(0, 0, 668, 96);
		add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton_2_2 = new JButton("");
		btnNewButton_2_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login.functionframe.setExtendedState(JFrame.ICONIFIED);
			}
		});
		btnNewButton_2_2.setIcon(new ImageIcon(InterfaceAccount.class.getResource("/Pic/green.png")));
		btnNewButton_2_2.setBackground(Color.CYAN);
		btnNewButton_2_2.setBounds(598, 10, 15, 15);
		panel.add(btnNewButton_2_2);
		
		JButton btnNewButton_2_2_1 = new JButton("");
		btnNewButton_2_2_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_2_2_1.setIcon(new ImageIcon(InterfaceAccount.class.getResource("/Pic/red.png")));
		btnNewButton_2_2_1.setBackground(Color.CYAN);
		btnNewButton_2_2_1.setBounds(639, 10, 15, 15);
		panel.add(btnNewButton_2_2_1);
		
		JButton btnNewButton_1 = new JButton("\u786E\u8BA4\u4FEE\u6539");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				//�޸��˺�
				String deletename = new String();
				deletename = (String) comboBox.getSelectedItem();
				System.out.println("ɾ��"+deletename);
				int opt = JOptionPane.showConfirmDialog(null, "ȷ���޸���?"," ",JOptionPane.OK_CANCEL_OPTION );  //0ȷ��  2ȡ��
				if(opt==0) {//ȷ��
					Database.joinDB();  //�������ݿ�
					deletename = (String) comboBox.getSelectedItem();
					String mySql = "update DBUSER set MYPASSWORD = '"+ textField_2.getText() +"' "+ "where MYID = '"+ deletename +"'";
					textField_2.setText("");
					Database.executeSQL(mySql);   //ִ�в�ѯ
					String sql="select * from DBUSER";
					if(Database.joinDB()) {
				        try{
				            Database.rs= Database.executeQuery(sql);    
				            comboBox.removeAllItems();
				        	if(Database.recCount(Database.rs)>0){ 
				         		while(Database.rs.next()){
				         			String name=Database.rs.getString("MYID");
				         			comboBox.addItem(name);
				         		}
				         	}
				        }
				        catch(Exception e){}			
					}
				}else {
					
				}
			}
		});
		btnNewButton_1.setBounds(473, 389, 91, 36);
		add(btnNewButton_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(269, 390, 182, 36);
		add(textField_2);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("\u65B0\u7684\u5BC6\u7801\uFF1A");
		lblNewLabel_1_1_1_1.setBounds(177, 390, 67, 33);
		add(lblNewLabel_1_1_1_1);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1_1.setBounds(108, 312, 472, 156);
		add(panel_1_1);
		
		JButton btnNewButton_2_1 = new JButton("\u91CD\u65B0\u767B\u9646");
		btnNewButton_2_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) { 
				newlogin = new Login(); 
				newlogin.setVisible(true); 
				Login.functionframe.dispose();
			}
		});
		btnNewButton_2_1.setBounds(361, 260, 91, 33);
		add(btnNewButton_2_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(108, 106, 472, 200);
		add(panel_1);
		
		
		String sql="select * from DBUSER";
		if(Database.joinDB()) {
	        try{
	        	comboBox.removeAllItems();
	            Database.rs= Database.executeQuery(sql);        	
	        	if(Database.recCount(Database.rs)>0){ 
	         		while(Database.rs.next()){
	         			String name=Database.rs.getString("MYID");
	         			comboBox.addItem(name);
	         		}
	         	}
	        }
	        catch(Exception e){}			
		}   
	}
	
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					JFrame frame = new JFrame();
//					frame.setBounds(10, 91, 634, 356);
//					frame.getContentPane().add( new InterfaceAccount() );
//					frame.setVisible(true); 
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
}
