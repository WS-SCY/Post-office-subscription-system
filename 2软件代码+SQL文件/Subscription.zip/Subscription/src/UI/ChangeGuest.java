package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import UI.Database;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class ChangeGuest extends JPanel {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JButton btnNewButton;
	JScrollPane scrollPane;
   	JTable table;
   	private ResultSet rs;
	DefaultTableModel dtm;
	String columns[] =  {"���","����","�绰","��ַ","��������"};
	private JLabel lblNewLabel_1_2;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					ChangeGuest frame = new ChangeGuest();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public ChangeGuest() {
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dtm = new DefaultTableModel();
		dtm.setColumnCount(5);
		dtm.setColumnIdentifiers(columns);
		
		table = new JTable(dtm); 
 
		
		
		setBounds(100, 100, 545, 344);
		setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(23, 59, 75, 26);
		add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u59D3\u540D");
		lblNewLabel_1.setBounds(8, 131, 60, 23);
		add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(41, 130, 75, 26);
		add(textField_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u7535\u8BDD");
		lblNewLabel_2.setBounds(8, 164, 60, 23);
		add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(41, 164, 75, 26);
		add(textField_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u5730\u5740");
		lblNewLabel_3.setBounds(8, 202, 60, 23);
		add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(41, 201, 75, 26);
		add(textField_3);
		
		JLabel lblNewLabel_4 = new JLabel("\u90AE\u7F16");
		lblNewLabel_4.setBounds(8, 237, 60, 23);
		add(lblNewLabel_4);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(41, 236, 75, 26);
		add(textField_4);
		
		btnNewButton = new JButton("\u66F4\u6539");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("�޸Ĺ˿���Ϣ");  
				 

				Database.joinDB();
        		String mySql = "select GNO,GNA,GTE,G.GAD,AD.GPO from G,AD "; 
        		if(textField.getText().equals("") ||textField_1.getText().equals("")||textField_2.getText().equals("")||textField_3.getText().equals("")||textField_4.getText().equals("")) {
        			int opt = JOptionPane.showConfirmDialog(null, "��������������Ϣ��","",JOptionPane.DEFAULT_OPTION);  //0ȷ��  2ȡ��
        		}else {
        			int opt = JOptionPane.showConfirmDialog(null, "ȷ���޸���Ϣ��?","",JOptionPane.OK_CANCEL_OPTION );  //0ȷ��  2ȡ��
        			if(opt == 0) {
        				mySql = "update G set GNA = '"+ textField_1.getText()+"' ,GTE = '"+textField_2.getText()+"' ,G.GAD ='"+textField_3.getText()+"' where GNO = '"+ textField.getText() +"'";
            			Database.executeSQL(mySql);
                   		System.out.println(mySql);
                   		mySql = "update AD set GPO = '"+textField_4.getText()+"' where GAD = '"+textField_3.getText()+"'";
            		    
                   		Database.rs = Database.executeQuery("select * from AD where GPO = '"+textField_4.getText() +"' and GAD = '"+textField_3.getText()+"'" );
                   		if(Database.recCount(Database.rs)>0 ) {
                   			System.out.println("AD changed");
                   		}
            		    else{
            		    	System.out.println("�����µ�ֵ");
            		    	Database.executeSQL( String.format("insert into AD values('%s','%s')",textField_3.getText(),textField_4.getText() ) );
            		    }
            		    rs=Database.executeQuery("select GNO,GNA,GTE,G.GAD,AD.GPO from G,AD where AD.GAD = G.GAD ");
                		int rc=dtm.getRowCount(); 
                	    for(int i=0;i<rc;i++){
                			dtm.removeRow(0);
                		} 
                	    
            			if(Database.recCount(rs)>0){ 
            				try{ 
            					while(rs.next()){ 
            						String GNO = rs.getString("GNO");  
            						String GNA = rs.getString("GNA");  
            						String GTE =  rs.getString("GTE");  
            						String GAD = rs.getString("GAD");   
            						String GPO = rs.getString("GPO");   
            						Vector v = new Vector(); 
            						v.add(GNO);
            						v.add(GNA);
            						v.add(GTE);
            						v.add(GAD);
            						v.add(GPO);  
            						dtm.addRow(v); 
            						}
            				}
            			   	catch(Exception eRIQ){}
            			}
        			} 
        		}
 
			}
		});
		btnNewButton.setBounds(23, 282, 75, 23);
		add(btnNewButton);
		
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(126, 10, 391, 295);
		add(scrollPane);
		
		JLabel lblNewLabel_1_1 = new JLabel("\u8981\u66F4\u65B0\u7684\u7F16\u53F7\uFF1A");
		lblNewLabel_1_1.setBounds(8, 23, 95, 26);
		add(lblNewLabel_1_1);
		
		lblNewLabel_1_2 = new JLabel("\u8981\u66F4\u65B0\u7684\u503C\uFF1A");
		lblNewLabel_1_2.setBounds(25, 95, 95, 26);
		add(lblNewLabel_1_2);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
//		setContentPane(contentPane);
		rs=Database.executeQuery("select GNO,GNA,GTE,G.GAD,AD.GPO from G,AD where AD.GAD = G.GAD ");
		if(Database.recCount(rs)>0){ 
			try{ 
				while(rs.next()){ 
					String GNO = rs.getString("GNO");  
					String GNA = rs.getString("GNA");  
					String GTE =  rs.getString("GTE");  
					String GAD = rs.getString("GAD");   
					String GPO = rs.getString("GPO");   
					Vector v = new Vector(); 
					v.add(GNO);
					v.add(GNA);
					v.add(GTE);
					v.add(GAD);
					v.add(GPO);  
					dtm.addRow(v); 
					}
			}
		   	catch(Exception eRIQ){}
		}
	}
}
