package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import UI.Database;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class QueryGP extends JPanel {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JButton btnNewButton;
	JScrollPane scrollPane;
   	JTable table;
   	private ResultSet rs;
	DefaultTableModel dtm;
	String columns[] =  {"�˿���","�˿ͱ��","��ֽ��","��ֽ���","�������","Ӧ������"};
	private JTextField textField_3;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					QueryGP frame = new QueryGP();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public QueryGP() {
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dtm = new DefaultTableModel();
		dtm.setColumnCount(6);
		dtm.setColumnIdentifiers(columns);
		
		table = new JTable(dtm); 
 
		
		
		setBounds(100, 100, 545, 344);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u987E\u5BA2\u53F7");
		lblNewLabel.setBounds(10, 66, 60, 23);
		add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(53, 65, 75, 26);
		add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u62A5\u7EB8\u53F7");
		lblNewLabel_1.setBounds(10, 101, 60, 23);
		add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(53, 99, 75, 26);
		add(textField_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u4EFD\u6570");
		lblNewLabel_2.setBounds(10, 134, 60, 23);
		add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(53, 134, 75, 26);
		add(textField_2);
		
		btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("��ѯ�˿���Ϣ");  
				 
        		int rc=dtm.getRowCount(); 
        	    for(int i=0;i<rc;i++){
        			dtm.removeRow(0);
        		} 
        	    
        	    Database.joinDB();
        		String mySql = "select  GNA,G.GNO,P.PNA,P.PNO,PPR,N from G,P,PG where G.GNO = PG.GNO and P.PNO = PG.PNO";
        		Boolean myflag = new Boolean(true);
        		if(textField.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and G.GNO = "+"'"+textField.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where G.GNO = "+"'"+textField.getText()+"'";
        			}
        		}
        		if(textField_1.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and P.PNO = "+"'"+textField_1.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where P.PNO = "+"'"+textField_1.getText()+"'";
        			}
        		}
        		if(textField_2.getText().equals("")) ;
        		else {
        			if(myflag==true) {
        				mySql += " and N = "+"'"+textField_2.getText()+"'";
        			}else {//��һ��
        				myflag = true;
        				mySql += " where N = "+"'"+textField_2.getText()+"'";
        			}
        		}
        		int tem = 0;
        		System.out.println(mySql);
        		rs=Database.executeQuery(mySql);
        		System.out.println("��ѯ����");
        		if(Database.recCount(rs)>0){ 
        			try{ 
        				while(rs.next()){ 
        					String GNA = rs.getString("GNA");  
        					String GNO = rs.getString("GNO");
        					String PNA = rs.getString("PNA");  
        					String PNO = rs.getString("PNO");
        					int N =  rs.getInt("N");  
        					int PPR = rs.getInt("PPR");     
        					Vector v = new Vector(); 
        					v.add(GNA); 
        					v.add(GNO);
        					v.add(PNA);
        					v.add(PNO);
        					v.add(N);
        					v.add(N*PPR); tem = tem + N * PPR;  
        					dtm.addRow(v); 
        				}
        				textField_3.setText(String.format("%d", tem));
        			}
        		   	catch(Exception eRIQ){}
        		}
			}
		});
		btnNewButton.setBounds(25, 252, 75, 23);
		add(btnNewButton);
		
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(138, 10, 391, 295);
		add(scrollPane);
		
		JLabel lblNewLabel_2_1 = new JLabel("\u603B\u8D39\u7528");
		lblNewLabel_2_1.setBounds(411, 308, 60, 23);
		add(lblNewLabel_2_1);
		
		textField_3 = new JTextField();
		textField_3.setEditable(false);
		textField_3.setColumns(10);
		textField_3.setBounds(454, 308, 75, 26);
		add(textField_3);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
//		setContentPane(contentPane);
		rs=Database.executeQuery("select GNA,G.GNO,P.PNA,P.PNO,PPR,N from G,P,PG where G.GNO = PG.GNO and P.PNO = PG.PNO");
		if(Database.recCount(rs)>0){ 
			try{ 
				while(rs.next()){ 
					String GNA = rs.getString("GNA");  
					String GNO = rs.getString("GNO");
					String PNA = rs.getString("PNA");  
					String PNO = rs.getString("PNO");
					int N =  rs.getInt("N");  
					int PPR = rs.getInt("PPR");     
					Vector v = new Vector(); 
					v.add(GNA); 
					v.add(GNO);
					v.add(PNA);
					v.add(PNO);
					v.add(N);
					v.add(N*PPR);  
					dtm.addRow(v); 
				}
			}
		   	catch(Exception eRIQ){}
		}
	}
}
