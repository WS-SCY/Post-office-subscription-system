package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import UI.Database;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ChangeGP extends JPanel {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JButton btnNewButton;
	JScrollPane scrollPane;
   	JTable table;
   	private ResultSet rs;
	DefaultTableModel dtm;
	String columns[] =  {"�˿���","�˿ͱ��","��ֽ��","��ֽ���","�������","Ӧ������"};
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					ChangeGP frame = new ChangeGP();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public ChangeGP() {
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dtm = new DefaultTableModel();
		dtm.setColumnCount(6);
		dtm.setColumnIdentifiers(columns);
		
		table = new JTable(dtm); 
 
		
		
		setBounds(100, 100, 545, 344);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u987E\u5BA2\u7F16\u53F7\uFF1A");
		lblNewLabel.setBounds(25, 53, 75, 23);
		add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(25, 74, 75, 26);
		add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u62A5\u7EB8\u7F16\u53F7\uFF1A");
		lblNewLabel_1.setBounds(25, 112, 75, 23);
		add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(25, 135, 75, 26);
		add(textField_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u6539\u4EFD\u6570\u4E3A\uFF1A");
		lblNewLabel_2.setBounds(25, 194, 75, 23);
		add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(25, 216, 75, 26);
		add(textField_2);
		
		btnNewButton = new JButton("\u4FEE\u6539"); 
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("���Ĺ�����Ϣ");  
				Database.joinDB();
        		String mySql = ""; 
        		if(textField.getText().equals("") ||textField_1.getText().equals("")||textField_2.getText().equals("")) {
        			int opt = JOptionPane.showConfirmDialog(null, "��������������Ϣ��","",JOptionPane.DEFAULT_OPTION);  //0ȷ��  2ȡ��
        		}else {
        			int opt = JOptionPane.showConfirmDialog(null, "ȷ��������Ϣ��?","",JOptionPane.OK_CANCEL_OPTION );  //0ȷ��  2ȡ��
        			if(opt == 0) {
        				mySql = "update PG set N = "+ textField_2.getText()+"  where GNO = '"+textField.getText()+"' and PNO='"+textField_1.getText()+"'";
            			Database.executeSQL(mySql);
                   		System.out.println(mySql);   
                		int row=dtm.getRowCount(); 
                	    for(int i=0;i<row;i++){
                			dtm.removeRow(0);
                		} 
                		rs=Database.executeQuery("select GNA,G.GNO,P.PNA,P.PNO,PPR,N from G,P,PG where G.GNO = PG.GNO and P.PNO = PG.PNO");
                		if(Database.recCount(rs)>0){ 
                			try{ 
                				while(rs.next()){ 
                					String GNA = rs.getString("GNA");  
                					String GNO = rs.getString("GNO");
                					String PNA = rs.getString("PNA");  
                					String PNO = rs.getString("PNO");
                					int N =  rs.getInt("N");  
                					int PPR = rs.getInt("PPR");     
                					Vector v = new Vector(); 
                					v.add(GNA); 
                					v.add(GNO);
                					v.add(PNA);
                					v.add(PNO);
                					v.add(N);
                					v.add(N*PPR);  
                					dtm.addRow(v); 
                				}
                			}
                		   	catch(Exception eRIQ){}
                		}
        			} 
        		} 
			}
		});
		btnNewButton.setBounds(25, 252, 75, 23);
		add(btnNewButton);
		
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(138, 10, 391, 295);
		add(scrollPane);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
//		setContentPane(contentPane);
		rs=Database.executeQuery("select GNA,G.GNO,P.PNA,P.PNO,PPR,N from G,P,PG where G.GNO = PG.GNO and P.PNO = PG.PNO");
		if(Database.recCount(rs)>0){ 
			try{ 
				while(rs.next()){ 
					String GNA = rs.getString("GNA");  
					String GNO = rs.getString("GNO");
					String PNA = rs.getString("PNA");  
					String PNO = rs.getString("PNO");
					int N =  rs.getInt("N");  
					int PPR = rs.getInt("PPR");     
					Vector v = new Vector(); 
					v.add(GNA); 
					v.add(GNO);
					v.add(PNA);
					v.add(PNO);
					v.add(N);
					v.add(N*PPR);  
					dtm.addRow(v); 
				}
			}
		   	catch(Exception eRIQ){}
		}
	}
}
